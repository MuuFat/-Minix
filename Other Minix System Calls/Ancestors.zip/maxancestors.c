#include <stdio.h>
#include <stdlib.h>
#include <lib.h>
#include <unistd.h>
#include <sys/wait.h>

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        printf("No. of processes to create not specified.\n");
        return 0;
    }

    int processes_to_create = atoi(argv[1]);
    for (int i = 0; i < processes_to_create; i++)
    {
        if (fork() == 0)
        {
            printf("Child no. %d created\n", i);
            sleep(10);
            return 0;
        }
    }

    message m;
    int ret;

    printf("Parent PID: %d\n", getpid());
    ret = _syscall(PM_PROC_NR, PM_MAXANCESTORS, &m);
    printf("syscall return - PID - no. of ancestors: %d\n", ret);
    ret = _syscall(PM_PROC_NR, PM_WHOMAXANCESTORS, &m);
    printf("syscall return - PID - max no. of ancestors: %d\n", ret);
    wait(NULL);
    return 0;
}
